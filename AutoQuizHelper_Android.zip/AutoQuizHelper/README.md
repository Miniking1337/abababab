# AutoQuizHelper（Android 自动识屏答题助手）

一款运行在 Android 手机端（最低支持 Android 8.0 / API 26，适配 Android 14+）的原生 Kotlin 自动答题程序。支持**单选、多选、判断、填空**等常见题型，**不依赖固定选项坐标**。

## 核心工作原理

1. **屏幕采集**：通过系统 `MediaProjection` + `VirtualDisplay` 实时获取当前屏幕画面。
2. **智能双模解题**：
   - **有网模式**：将屏幕截图压缩编码后发送给兼容 OpenAI 格式的多模态视觉大模型 API（如 GPT-4o、通义千问 VL、Gemini Flash 等），直接得出题型与答案文本。
   - **离线 / 断网自动兜底**：调用内置的 Google ML Kit 离线中文 OCR（`text-recognition-chinese`）提取屏幕文字，匹配本地 Room SQLite 题库（支持模糊匹配）。
3. **动态坐标定位与自动作答**：
   - 针对**选项位置不固定**的场景，利用 ML Kit OCR 返回的每个文本框精确矩形坐标（`Rect`），将答案文本与屏幕选项实时匹配，计算中心点 `(x, y)` 后通过 `AccessibilityService.dispatchGesture` 自动模拟点击（多选题自动依次点击）。
   - 针对**填空题**，自动遍历当前窗口中的可编辑输入框（`isEditable`），通过 `ACTION_SET_TEXT` 自动填入答案。

## 编译与运行步骤

1. 使用 **Android Studio**（建议 Iguana / Jellyfish 或更新版本）打开解压后的 `AutoQuizHelper` 目录。
2. 等待 Gradle 同步完成（需确保网络可访问 Google Maven 与 Maven Central）。
3. 连接安卓手机（开启 USB 调试）或使用真机打包 APK 安装。
4. 打开 App，依次完成以下配置：
   - 开启 **悬浮窗权限** 与 **无障碍服务（自动答题点击服务）**。
   - 填入你的大模型 API Base URL、API Key 与视觉模型名称并保存（如需纯离线测试可勾选“强制仅使用本地题库”）。
   - 点击“载入示例题库”或“导入 JSON 题库”（格式可参考工程根目录下的 `sample_question_bank.json`）。
5. 点击 **“启动悬浮窗并授权截屏”**，切换到任意答题界面，点击悬浮窗上的 **“识别答题”** 按钮即可。
