package com.autoquiz.helper.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.autoquiz.helper.model.OcrLineBox
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OcrEngine {
    private val recognizer = TextRecognition.getClient(
        ChineseTextRecognizerOptions.Builder().build()
    )

    suspend fun recognize(bitmap: Bitmap): List<OcrLineBox> =
        suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val lines = mutableListOf<OcrLineBox>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val rect = line.boundingBox ?: continue
                            val text = line.text.trim()
                            if (text.isNotEmpty()) {
                                lines.add(OcrLineBox(text = text, rect = rect))
                            }
                        }
                    }
                    cont.resume(lines)
                }
                .addOnFailureListener { e ->
                    cont.resumeWithException(e)
                }
        }

    /**
     * 针对“选项位置不固定”的核心坐标定位逻辑：
     * 将大模型或本地题库返回的答案文字，与屏幕 OCR 识别出的行文本框进行模糊匹配，
     * 返回每个答案在屏幕上的真实矩形区域。
     */
    fun findMatchingRects(ocrLines: List<OcrLineBox>, targetAnswers: List<String>): List<Rect> {
        val matchedRects = mutableListOf<Rect>()
        for (answer in targetAnswers) {
            val cleanAnswer = normalize(answer)
            if (cleanAnswer.isEmpty()) continue

            var bestLine: OcrLineBox? = null
            var bestScore = 0.0

            for (line in ocrLines) {
                val cleanLine = normalize(line.text)
                if (cleanLine.isEmpty()) continue

                val score = similarity(cleanLine, cleanAnswer)
                if (score > bestScore) {
                    bestScore = score
                    bestLine = line
                }
            }

            if (bestLine != null && bestScore >= 0.45) {
                matchedRects.add(bestLine.rect)
            }
        }
        return matchedRects
    }

    private fun normalize(text: String): String {
        return text.lowercase()
            .replace(Regex("^[a-dA-D][.、:：\s]+"), "")
            .replace(Regex("[\s\p{P}]"), "")
    }

    private fun similarity(line: String, target: String): Double {
        if (line == target) return 1.0
        if (line.contains(target) || target.contains(line)) {
            val minLen = minOf(line.length, target.length).toDouble()
            val maxLen = maxOf(line.length, target.length).toDouble()
            return 0.75 + 0.25 * (minLen / maxLen)
        }
        val lineChars = line.toSet()
        val targetChars = target.toSet()
        val intersection = lineChars.intersect(targetChars).size.toDouble()
        val union = lineChars.union(targetChars).size.toDouble()
        return if (union == 0.0) 0.0 else intersection / union
    }
}
