package com.autoquiz.helper.solver

import android.graphics.Bitmap
import android.util.Base64
import com.autoquiz.helper.model.AppConfig
import com.autoquiz.helper.model.QuestionType
import com.autoquiz.helper.model.QuizAnswerResult
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class OnlineLlmSolver {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    suspend fun solve(bitmap: Bitmap, config: AppConfig): QuizAnswerResult? =
        withContext(Dispatchers.IO) {
            if (config.apiKey.isBlank() || config.apiUrl.isBlank()) return@withContext null

            val base64Image = bitmapToBase64(bitmap)
            val prompt = """
                你是一个精准的屏幕答题助手。请识别图片中的题目和所有选项，并只返回严格的 JSON（不要包含 Markdown 代码块或其他多余解释）。
                JSON 格式要求：
                {
                  "type": "SINGLE_CHOICE" | "MULTIPLE_CHOICE" | "TRUE_FALSE" | "FILL_BLANK",
                  "answers": ["与屏幕上选项完全一致的文字，或填空题应填入的答案"],
                  "reasoning": "不超过20字的简短依据"
                }
                注意：
                1. 如果是选择题或判断题，answers 数组中的每一项必须是屏幕上对应选项的完整可见文字（包含或不包含 A/B/C/D 前缀均可，但内容要准确），方便后续在屏幕上进行 OCR 坐标匹配点击。
                2. 如果是多选题，answers 数组中列出所有正确选项文字。
                3. 如果是填空题，answers 数组中按顺序给出要填入的答案文本。
            """.trimIndent()

            val payload = JsonObject().apply {
                addProperty("model", config.modelName)
                addProperty("temperature", 0.1)
                val messages = com.google.gson.JsonArray()
                val userMsg = JsonObject().apply {
                    addProperty("role", "user")
                    val contentArr = com.google.gson.JsonArray()
                    contentArr.add(JsonObject().apply {
                        addProperty("type", "text")
                        addProperty("text", prompt)
                    })
                    contentArr.add(JsonObject().apply {
                        addProperty("type", "image_url")
                        add("image_url", JsonObject().apply {
                            addProperty("url", "data:image/jpeg;base64,$base64Image")
                        })
                    })
                    add("content", contentArr)
                }
                messages.add(userMsg)
                add("messages", messages)
            }

            val request = Request.Builder()
                .url(config.apiUrl.trim())
                .addHeader("Authorization", "Bearer ${config.apiKey.trim()}")
                .addHeader("Content-Type", "application/json")
                .post(gson.toJson(payload).toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val bodyStr = response.body?.string() ?: return@withContext null
                val root = gson.fromJson(bodyStr, JsonObject::class.java)
                val content = root.getAsJsonArray("choices")
                    ?.firstOrNull()?.asJsonObject
                    ?.getAsJsonObject("message")
                    ?.get("content")?.asString
                    ?: return@withContext null

                parseAnswerJson(content)
            }
        }

    private fun parseAnswerJson(raw: String): QuizAnswerResult? {
        val cleaned = raw.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        return runCatching {
            val obj = gson.fromJson(cleaned, JsonObject::class.java)
            val typeStr = obj.get("type")?.asString ?: "UNKNOWN"
            val type = runCatching { QuestionType.valueOf(typeStr) }
                .getOrDefault(QuestionType.UNKNOWN)
            val answers = obj.getAsJsonArray("answers")
                ?.mapNotNull { it.asString?.trim() }
                ?.filter { it.isNotEmpty() }
                ?: emptyList()
            val reasoning = obj.get("reasoning")?.asString ?: ""

            if (answers.isEmpty()) null
            else QuizAnswerResult(
                questionType = type,
                answers = answers,
                confidence = 0.95f,
                source = "在线大模型",
                reasoning = reasoning
            )
        }.getOrNull()
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val maxWidth = 1080
        val scaled = if (bitmap.width > maxWidth) {
            val ratio = maxWidth.toFloat() / bitmap.width
            Bitmap.createScaledBitmap(
                bitmap,
                maxWidth,
                (bitmap.height * ratio).toInt(),
                true
            )
        } else {
            bitmap
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
