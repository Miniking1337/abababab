package com.autoquiz.helper.solver

import com.autoquiz.helper.db.QuestionDao
import com.autoquiz.helper.db.QuestionEntity
import com.autoquiz.helper.model.OcrLineBox
import com.autoquiz.helper.model.QuestionType
import com.autoquiz.helper.model.QuizAnswerResult

class OfflineQuestionSolver(private val questionDao: QuestionDao) {

    suspend fun solve(ocrLines: List<OcrLineBox>): QuizAnswerResult? {
        val fullScreenText = normalize(ocrLines.joinToString(" ") { it.text })
        if (fullScreenText.isEmpty()) return null

        val allQuestions = questionDao.getAll()
        var bestMatch: QuestionEntity? = null
        var bestScore = 0.0

        for (q in allQuestions) {
            val qNorm = normalize(q.questionText)
            if (qNorm.isEmpty()) continue

            val score = when {
                fullScreenText.contains(qNorm) -> 0.95
                else -> charOverlapScore(fullScreenText, qNorm)
            }
            if (score > bestScore) {
                bestScore = score
                bestMatch = q
            }
        }

        if (bestMatch == null || bestScore < 0.45) return null

        val type = runCatching { QuestionType.valueOf(bestMatch.questionType) }
            .getOrDefault(QuestionType.SINGLE_CHOICE)
        val answers = bestMatch.answerText.split("|")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        return QuizAnswerResult(
            questionType = type,
            answers = answers,
            confidence = bestScore.toFloat(),
            source = "本地离线题库"
        )
    }

    private fun normalize(s: String): String =
        s.lowercase().replace(Regex("[\\s\\p{P}]"), "")

    private fun charOverlapScore(screenText: String, questionText: String): Double {
        val qChars = questionText.toSet()
        if (qChars.isEmpty()) return 0.0
        val hit = qChars.count { it in screenText }
        return hit.toDouble() / qChars.size.toDouble()
    }
}
