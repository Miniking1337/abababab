package com.autoquiz.helper.model

import android.graphics.Rect

enum class QuestionType {
    SINGLE_CHOICE,
    MULTIPLE_CHOICE,
    TRUE_FALSE,
    FILL_BLANK,
    UNKNOWN
}

data class OcrLineBox(
    val text: String,
    val rect: Rect
)

data class QuizAnswerResult(
    val questionType: QuestionType,
    val answers: List<String>,
    val confidence: Float,
    val source: String,
    val reasoning: String = ""
)

data class AppConfig(
    val apiUrl: String,
    val apiKey: String,
    val modelName: String,
    val preferOffline: Boolean
)
