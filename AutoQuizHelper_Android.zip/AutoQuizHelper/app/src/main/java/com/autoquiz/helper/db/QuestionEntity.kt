package com.autoquiz.helper.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionText: String,
    val questionType: String, // SINGLE_CHOICE, MULTIPLE_CHOICE, TRUE_FALSE, FILL_BLANK
    val answerText: String,   // 多选用 | 分隔，如 "选项A|选项C"
    val keywords: String = ""
)
