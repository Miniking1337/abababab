package com.autoquiz.helper.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay

class AutoTapAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoTapAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 按需通过悬浮窗触发截屏与答题，此处保持轻量
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    suspend fun tapRectsSequentially(rects: List<Rect>) {
        for (rect in rects) {
            val x = rect.centerX().toFloat()
            val y = rect.centerY().toFloat()
            tapPoint(x, y)
            delay(320L)
        }
    }

    fun tapPoint(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * 针对填空题：遍历当前活跃窗口中的可编辑输入框并自动填入答案
     */
    fun inputTextToEditableNodes(answers: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        collectEditableNodes(root, editableNodes)

        if (editableNodes.isEmpty()) return false

        var successCount = 0
        editableNodes.forEachIndexed { index, node ->
            val textToFill = answers.getOrNull(index) ?: answers.firstOrNull() ?: return@forEachIndexed
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    textToFill
                )
            }
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                successCount++
            }
        }
        return successCount > 0
    }

    private fun collectEditableNodes(
        node: AccessibilityNodeInfo,
        out: MutableList<AccessibilityNodeInfo>
    ) {
        if (node.isEditable) {
            out.add(node)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectEditableNodes(it, out) }
        }
    }
}
