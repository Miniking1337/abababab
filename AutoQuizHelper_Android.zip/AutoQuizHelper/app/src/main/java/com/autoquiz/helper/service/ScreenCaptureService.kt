package com.autoquiz.helper.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.autoquiz.helper.R
import com.autoquiz.helper.model.AppConfig
import com.autoquiz.helper.solver.QuizCoordinator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "auto_quiz_capture"
        private const val NOTIF_ID = 1001
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var floatView: View? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 320

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var coordinator: QuizCoordinator
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        coordinator = QuizCoordinator(this)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }
        initMetrics()
        showFloatingWindow()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null && mediaProjection == null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpm.getMediaProjection(resultCode, resultData)
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    releaseProjection()
                }
            }, mainHandler)
            setupVirtualDisplay()
        }
        return START_NOT_STICKY
    }

    private fun initMetrics() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    private fun setupVirtualDisplay() {
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "AutoQuizCapture",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        )
    }

    private fun showFloatingWindow() {
        if (floatView != null) return
        val inflater = LayoutInflater.from(this)
        floatView = inflater.inflate(R.layout.layout_floating_ball, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 220
        }

        val tvStatus = floatView!!.findViewById<TextView>(R.id.tvFloatStatus)
        val btnSolve = floatView!!.findViewById<Button>(R.id.btnSolveOnce)
        val btnClose = floatView!!.findViewById<TextView>(R.id.btnCloseFloat)
        val dragHandle = floatView!!.findViewById<TextView>(R.id.tvDragHandle)

        setupDrag(dragHandle, params)

        btnSolve.setOnClickListener {
            btnSolve.isEnabled = false
            serviceScope.launch {
                val bitmap = captureCurrentScreen()
                if (bitmap == null) {
                    tvStatus.text = "截屏失败，请重试"
                } else {
                    coordinator.processScreen(bitmap, loadConfig()) { status ->
                        tvStatus.text = status
                    }
                    bitmap.recycle()
                }
                btnSolve.isEnabled = true
            }
        }

        btnClose.setOnClickListener {
            stopSelf()
        }

        windowManager?.addView(floatView, params)
    }

    private fun setupDrag(handle: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatView, params)
                    true
                }
                else -> false
            }
        }
    }

    private suspend fun captureCurrentScreen(): Bitmap? = withContext(Dispatchers.IO) {
        // 丢弃旧帧，确保获取最新屏幕画面
        imageReader?.acquireLatestImage()?.close()
        delay(80)
        val image = imageReader?.acquireLatestImage() ?: return@withContext null
        image.use {
            val plane = it.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val fullBitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            fullBitmap.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, screenWidth, screenHeight)
            if (cropped !== fullBitmap) fullBitmap.recycle()
            cropped
        }
    }

    private fun loadConfig(): AppConfig {
        val prefs = getSharedPreferences("auto_quiz_prefs", Context.MODE_PRIVATE)
        return AppConfig(
            apiUrl = prefs.getString("api_url", "https://api.openai.com/v1/chat/completions") ?: "",
            apiKey = prefs.getString("api_key", "") ?: "",
            modelName = prefs.getString("model_name", "gpt-4o") ?: "gpt-4o",
            preferOffline = prefs.getBoolean("prefer_offline", false)
        )
    }

    private fun releaseProjection() {
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "自动识屏答题服务",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("自动识屏答题运行中")
            .setContentText("点击悬浮窗按钮即可识别当前屏幕并自动答题")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        floatView?.let { windowManager?.removeView(it) }
        floatView = null
        releaseProjection()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
