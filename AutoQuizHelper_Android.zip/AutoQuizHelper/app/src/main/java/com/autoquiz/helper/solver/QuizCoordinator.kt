package com.autoquiz.helper.solver

import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.autoquiz.helper.db.QuizDatabase
import com.autoquiz.helper.model.AppConfig
import com.autoquiz.helper.model.QuestionType
import com.autoquiz.helper.model.QuizAnswerResult
import com.autoquiz.helper.ocr.OcrEngine
import com.autoquiz.helper.service.AutoTapAccessibilityService

class QuizCoordinator(private val context: Context) {
    private val ocrEngine = OcrEngine()
    private val onlineSolver = OnlineLlmSolver()
    private val offlineSolver = OfflineQuestionSolver(
        QuizDatabase.getInstance(context).questionDao()
    )

    suspend fun processScreen(
        bitmap: Bitmap,
        config: AppConfig,
        onStatus: (String) -> Unit
    ) {
        onStatus("OCR 识别屏幕中...")
        val ocrLines = ocrEngine.recognize(bitmap)

        val useOnline = !config.preferOffline && isNetworkAvailable() && config.apiKey.isNotBlank()
        var result: QuizAnswerResult? = null

        if (useOnline) {
            onStatus("请求大模型分析...")
            result = runCatching { onlineSolver.solve(bitmap, config) }.getOrNull()
        }

        if (result == null) {
            onStatus("查询本地题库...")
            result = offlineSolver.solve(ocrLines)
        }

        if (result == null) {
            onStatus("未找到匹配答案")
            return
        }

        val service = AutoTapAccessibilityService.instance
        if (service == null) {
            onStatus("无障碍服务未开启")
            return
        }

        when (result.questionType) {
            QuestionType.FILL_BLANK -> {
                val filled = service.inputTextToEditableNodes(result.answers)
                onStatus(if (filled) "${result.source}: 已填入答案" else "未找到可输入文本框")
            }
            else -> {
                val targetRects = ocrEngine.findMatchingRects(ocrLines, result.answers)
                if (targetRects.isEmpty()) {
                    onStatus("${result.source}: 答案[${result.answers.joinToString()}]未定位到坐标")
                } else {
                    service.tapRectsSequentially(targetRects)
                    onStatus("${result.source}: 已点击 ${targetRects.size} 项")
                }
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
