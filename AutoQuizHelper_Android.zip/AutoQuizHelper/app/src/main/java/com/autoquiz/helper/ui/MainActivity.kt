package com.autoquiz.helper.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.autoquiz.helper.databinding.ActivityMainBinding
import com.autoquiz.helper.db.QuestionEntity
import com.autoquiz.helper.db.QuizDatabase
import com.autoquiz.helper.service.AutoTapAccessibilityService
import com.autoquiz.helper.service.ScreenCaptureService
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "悬浮窗已启动，请切换到答题界面", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "未授予截屏权限", Toast.LENGTH_SHORT).show()
        }
    }

    private val importJsonLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        importBankFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSavedConfig()
        refreshBankCount()

        binding.btnGrantOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        binding.btnGrantAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnSaveConfig.setOnClickListener {
            saveConfig()
            Toast.makeText(this, "配置已保存", Toast.LENGTH_SHORT).show()
        }

        binding.btnImportJson.setOnClickListener {
            importJsonLauncher.launch(arrayOf("application/json", "text/plain"))
        }

        binding.btnLoadSampleBank.setOnClickListener {
            loadSampleQuestions()
        }

        binding.btnStartFloating.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先开启悬浮窗权限", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (AutoTapAccessibilityService.instance == null) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveConfig()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val a11yOk = AutoTapAccessibilityService.instance != null
        binding.tvPermissionStatus.text =
            "悬浮窗权限：${if (overlayOk) "已开启" else "未开启"}  |  " +
            "无障碍服务：${if (a11yOk) "已开启" else "未开启"}"
    }

    private fun loadSavedConfig() {
        val prefs = getSharedPreferences("auto_quiz_prefs", Context.MODE_PRIVATE)
        binding.etApiUrl.setText(
            prefs.getString("api_url", "https://api.openai.com/v1/chat/completions")
        )
        binding.etApiKey.setText(prefs.getString("api_key", ""))
        binding.etModelName.setText(prefs.getString("model_name", "gpt-4o"))
        binding.switchPreferOffline.isChecked = prefs.getBoolean("prefer_offline", false)
    }

    private fun saveConfig() {
        getSharedPreferences("auto_quiz_prefs", Context.MODE_PRIVATE).edit()
            .putString("api_url", binding.etApiUrl.text.toString().trim())
            .putString("api_key", binding.etApiKey.text.toString().trim())
            .putString("model_name", binding.etModelName.text.toString().trim())
            .putBoolean("prefer_offline", binding.switchPreferOffline.isChecked)
            .apply()
    }

    private fun refreshBankCount() {
        lifecycleScope.launch {
            val count = withContext(Dispatchers.IO) {
                QuizDatabase.getInstance(this@MainActivity).questionDao().count()
            }
            binding.tvBankCount.text = "当前本地题库数量：$count 题"
        }
    }

    private fun loadSampleQuestions() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val dao = QuizDatabase.getInstance(this@MainActivity).questionDao()
                dao.insertAll(
                    listOf(
                        QuestionEntity(
                            questionText = "中华人民共和国的首都是哪里",
                            questionType = "SINGLE_CHOICE",
                            answerText = "北京"
                        ),
                        QuestionEntity(
                            questionText = "以下哪些属于面向对象编程的基本特征",
                            questionType = "MULTIPLE_CHOICE",
                            answerText = "封装|继承|多态"
                        ),
                        QuestionEntity(
                            questionText = "地球是太阳系中距离太阳最近的行星",
                            questionType = "TRUE_FALSE",
                            answerText = "错误"
                        )
                    )
                )
            }
            refreshBankCount()
            Toast.makeText(this@MainActivity, "已载入示例题库", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importBankFromUri(uri: Uri) {
        lifecycleScope.launch {
            val importedCount = withContext(Dispatchers.IO) {
                runCatching {
                    val jsonText = contentResolver.openInputStream(uri)
                        ?.bufferedReader()?.use { it.readText() } ?: return@runCatching 0
                    val type = object : TypeToken<List<QuestionEntity>>() {}.type
                    val items: List<QuestionEntity> = Gson().fromJson(jsonText, type)
                    QuizDatabase.getInstance(this@MainActivity).questionDao().insertAll(items)
                    items.size
                }.getOrDefault(0)
            }
            refreshBankCount()
            Toast.makeText(
                this@MainActivity,
                if (importedCount > 0) "成功导入 $importedCount 题" else "导入失败，请检查 JSON 格式",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
